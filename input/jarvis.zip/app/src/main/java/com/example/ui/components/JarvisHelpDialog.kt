package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.DarkContainer
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.NeonCyanPrimary
import com.example.ui.theme.NeonSkySecondary
import com.example.ui.theme.TextCyanSecondary
import com.example.ui.theme.TextWhitePrimary

@Composable
fun JarvisHelpDialog(
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DarkContainer),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderCyanGlow, RoundedCornerShape(20.dp))
                .padding(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Build,
                            contentDescription = null,
                            tint = NeonCyanPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "JARVIS GUIDE & APK BUILD",
                            color = NeonCyanPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_help_dialog")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close guide",
                            tint = TextCyanSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                GuideSection(
                    icon = Icons.Default.Mic,
                    title = "1. Voice Commands (Hindi & English)",
                    content = "• Tap the glowing Mic button to speak.\n" +
                            "• Say \"YouTube kholo\", \"WhatsApp kholo\", \"Camera kholo\", \"Maps kholo\", or \"Chrome kholo\".\n" +
                            "• JARVIS answers out loud in Hindi using native Android Text-To-Speech (TTS).\n" +
                            "• You can also ask \"Time kya hai\", \"Battery kitni hai\", or general questions in the Chat terminal."
                )

                Spacer(modifier = Modifier.height(12.dp))

                GuideSection(
                    icon = Icons.Default.Security,
                    title = "2. Privacy & On-Demand Permissions",
                    content = "• Microphone permission is requested ONLY when you tap the mic button.\n" +
                            "• Zero background listening or covert recording.\n" +
                            "• Fully offline-capable basic assistant—no paid AI APIs required!"
                )

                Spacer(modifier = Modifier.height(12.dp))

                GuideSection(
                    icon = Icons.Default.PhoneAndroid,
                    title = "3. Testing in Emulator or Physical Phone",
                    content = "• In browser emulator: You can speak into your PC mic (allow browser mic permissions), or use the Chat tab and the Command Matrix to test all actions with 1 tap.\n" +
                            "• Installed vs Missing Apps: If an app (like WhatsApp) isn't installed in the emulator, JARVIS explains clearly in Hindi and provides a direct Google Play Store install button."
                )

                Spacer(modifier = Modifier.height(12.dp))

                GuideSection(
                    icon = Icons.Default.CheckCircle,
                    title = "4. How to Build an Installable APK",
                    content = "• Via AI Studio UI: Click the Settings / Project menu in the top right corner and select 'Export APK' or 'Download Project ZIP'.\n" +
                            "• Via Terminal / Android Studio: Run `gradle assembleDebug` inside the project folder. The generated APK will be at `app/build/outputs/apk/debug/app-debug.apk`.\n" +
                            "• Transfer this APK to any Android phone, tap to install, and enjoy your personal JARVIS assistant!"
                )

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyanPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Understood, Sir",
                        color = Color.Black,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun GuideSection(
    icon: ImageVector,
    title: String,
    content: String
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = CyberGreen,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = title,
                    color = NeonSkySecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = content,
                color = TextWhitePrimary,
                fontSize = 12.sp,
                lineHeight = 17.sp
            )
        }
    }
}
