package com.example.engine

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.MediaStore
import com.example.model.AppTarget
import com.example.model.ChatMessage
import com.example.model.SenderType
import com.example.model.SupportedApps
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class CommandResult(
    val spokenResponseHindi: String,
    val displayText: String,
    val actionExecuted: String? = null,
    val isAppLaunch: Boolean = false,
    val isError: Boolean = false,
    val playStorePackage: String? = null,
    val launchIntent: Intent? = null
)

class JarvisCommandEngine(private val context: Context) {

    fun executeQuery(inputQuery: String): CommandResult {
        val trimmed = inputQuery.trim()
        val query = trimmed.lowercase(Locale.ROOT)

        if (query.isEmpty()) {
            return CommandResult(
                spokenResponseHindi = "कृपया कुछ बोलें या टाइप करें, सर।",
                displayText = "कृपया कुछ बोलें या टाइप करें, सर। (Please speak or type a command)",
                isError = true
            )
        }

        // 1. App Launch Intent Checks
        val matchedApp = matchAppTarget(query)
        if (matchedApp != null) {
            return handleAppLaunch(matchedApp)
        }

        // 2. Camera Intent Check (special intent handling)
        if (isCameraCommand(query)) {
            return handleCameraLaunch()
        }

        // 3. System Utilities (Time, Date, Battery)
        if (isTimeCommand(query)) {
            return handleTimeQuery()
        }

        if (isDateCommand(query)) {
            return handleDateQuery()
        }

        if (isBatteryCommand(query)) {
            return handleBatteryQuery()
        }

        // 4. Identity & Greetings
        if (isGreetingCommand(query)) {
            return handleGreeting()
        }

        if (isIdentityCommand(query)) {
            return handleIdentity()
        }

        // 5. Help & Capabilities
        if (isHelpCommand(query)) {
            return handleHelp()
        }

        // 6. Joke / Humor
        if (isJokeCommand(query)) {
            return handleJoke()
        }

        // 7. Math / Calculation
        val mathResult = tryEvaluateMath(query)
        if (mathResult != null) {
            return mathResult
        }

        // 8. Web Search Command
        if (isSearchCommand(query)) {
            return handleSearch(query)
        }

        // 9. General Intelligent Fallback
        return handleGeneralQuery(trimmed)
    }

    private fun matchAppTarget(query: String): AppTarget? {
        val launchVerbs = listOf(
            "kholo", "khol do", "open", "launch", "start", "chalao", "chalu karo",
            "khol", "खोलो", "खोल दो", "चलाओ", "चालू करो", "ओपन"
        )
        val hasLaunchVerb = launchVerbs.any { query.contains(it) }

        for (app in SupportedApps.allApps) {
            // Check direct keywords
            val keywordMatch = app.keywords.any { query.contains(it) }
            val hindiMatch = app.hindiKeywords.any { query.contains(it) }

            if (keywordMatch || hindiMatch) {
                // If it contains the app name and a launch verb, or starts with "open" / ends with "kholo"
                if (hasLaunchVerb || query == app.id || query == app.nameEn.lowercase() || query == app.nameHi) {
                    return app
                }
                // Even without explicit verb, if query is basically the app name
                val sanitized = query.replace("jarvis", "").replace("जार्विस", "").trim()
                if (app.keywords.any { sanitized == it } || app.hindiKeywords.any { sanitized == it }) {
                    return app
                }
            }
        }
        return null
    }

    private fun isCameraCommand(query: String): Boolean {
        val cameraTriggers = listOf(
            "camera", "photo", "picture", "selfie", "pic",
            "कैमरा", "फोटो", "तस्वीर", "पिक्चर", "खींचो"
        )
        return cameraTriggers.any { query.contains(it) } &&
                (query.contains("kholo") || query.contains("open") || query.contains("chalao") ||
                        query.contains("khicho") || query.contains("le lo") || query.contains("खोलो") || query.contains("खींचो"))
    }

    private fun handleAppLaunch(app: AppTarget): CommandResult {
        // Special camera case
        if (app.id == "camera") {
            return handleCameraLaunch()
        }

        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(app.packageName)

        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val hindiVoice = "सर, ${app.nameHi} खोला जा रहा है।"
            val display = "🚀 Opening ${app.nameEn}...\n${app.nameHi} खोला जा रहा है, सर।"
            CommandResult(
                spokenResponseHindi = hindiVoice,
                displayText = display,
                actionExecuted = "Launched ${app.nameEn}",
                isAppLaunch = true,
                launchIntent = launchIntent
            )
        } else {
            // Check if fallback web action exists (e.g., YouTube web or Chrome web)
            val playStoreUri = Uri.parse("market://details?id=${app.playStorePackage}")
            val playStoreIntent = Intent(Intent.ACTION_VIEW, playStoreUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val hasPlayStore = pm.resolveActivity(playStoreIntent, PackageManager.MATCH_DEFAULT_ONLY) != null

            val hindiVoice = "माफ़ कीजिए सर, आपके फोन में ${app.nameHi} इनस्टॉल नहीं मिला। क्या आप इसे प्ले स्टोर से डाउनलोड करना चाहते हैं?"
            val display = "⚠️ ${app.nameEn} is not installed on this device.\n\n" +
                    "माफ़ कीजिए सर, आपके डिवाइस में ${app.nameHi} इनस्टॉल नहीं मिला।\n" +
                    "नीचे दिए गए बटन से आप इसे Google Play Store से डाउनलोड कर सकते हैं।"

            CommandResult(
                spokenResponseHindi = hindiVoice,
                displayText = display,
                actionExecuted = "${app.nameEn} not installed",
                isError = true,
                playStorePackage = app.playStorePackage,
                launchIntent = if (hasPlayStore) playStoreIntent else null
            )
        }
    }

    private fun handleCameraLaunch(): CommandResult {
        val cameraIntents = listOf(
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )

        for (intent in cameraIntents) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (intent.resolveActivity(context.packageManager) != null) {
                return CommandResult(
                    spokenResponseHindi = "सर, कैमरा शुरू किया जा रहा है।",
                    displayText = "📸 Opening Camera...\nकैमरा शुरू किया जा रहा है, सर।",
                    actionExecuted = "Launched Camera",
                    isAppLaunch = true,
                    launchIntent = intent
                )
            }
        }

        return CommandResult(
            spokenResponseHindi = "माफ़ कीजिए सर, डिवाइस में कैमरा ऐप नहीं खुला।",
            displayText = "⚠️ Camera app could not be opened on this device.",
            actionExecuted = "Camera unavailable",
            isError = true
        )
    }

    private fun isTimeCommand(query: String): Boolean {
        val triggers = listOf(
            "time", "samay", "kitne baje", "ghadi",
            "टाइम", "समय", "कितने बजे", "घड़ी"
        )
        return triggers.any { query.contains(it) }
    }

    private fun handleTimeQuery(): CommandResult {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR)
        val minute = calendar.get(Calendar.MINUTE)
        val amPm = if (calendar.get(Calendar.AM_PM) == Calendar.AM) "सुबह" else "शाम"
        val hourFormatted = if (hour == 0) 12 else hour

        val timeString = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val spoken = "सर, इस समय $amPm के $hourFormatted बजकर $minute मिनट हो रहे हैं।"
        val display = "🕒 Current Time: $timeString\n\n$spoken"

        return CommandResult(
            spokenResponseHindi = spoken,
            displayText = display,
            actionExecuted = "Queried Time"
        )
    }

    private fun isDateCommand(query: String): Boolean {
        val triggers = listOf(
            "date", "tareekh", "tarikh", "aaj kaun sa din", "today", "aaj kya hai",
            "डेट", "तारीख", "दिन", "आज क्या है"
        )
        return triggers.any { query.contains(it) }
    }

    private fun handleDateQuery(): CommandResult {
        val fullDateFormat = SimpleDateFormat("EEEE, d MMMM yyyy", Locale("hi", "IN"))
        val englishDateFormat = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.US)
        val today = Date()

        val hindiDate = fullDateFormat.format(today)
        val englishDate = englishDateFormat.format(today)

        val spoken = "सर, आज $hindiDate है।"
        val display = "📅 Today's Date:\n$englishDate\n\n$spoken"

        return CommandResult(
            spokenResponseHindi = spoken,
            displayText = display,
            actionExecuted = "Queried Date"
        )
    }

    private fun isBatteryCommand(query: String): Boolean {
        val triggers = listOf(
            "battery", "charge", "charging", "power",
            "बैटरी", "चार्जिंग", "चार्ज"
        )
        return triggers.any { query.contains(it) }
    }

    private fun handleBatteryQuery(): CommandResult {
        val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus: Intent? = context.registerReceiver(null, ifilter)

        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else 75

        val statusHindi = if (isCharging) "और फोन चार्ज हो रहा है।" else "है।"
        val spoken = "सर, आपके फोन की बैटरी $batteryPct प्रतिशत है $statusHindi"
        val display = "⚡ Battery Status: $batteryPct% ${if (isCharging) "(Charging)" else ""}\n\n$spoken"

        return CommandResult(
            spokenResponseHindi = spoken,
            displayText = display,
            actionExecuted = "Queried Battery"
        )
    }

    private fun isGreetingCommand(query: String): Boolean {
        val greetings = listOf(
            "hello", "hi", "namaste", "hey jarvis", "good morning", "good evening", "good afternoon",
            "नमस्ते", "हेलो", "हाय", "प्रणाम"
        )
        return greetings.any { query.contains(it) }
    }

    private fun handleGreeting(): CommandResult {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val greetingText = when (hour) {
            in 4..11 -> "सुप्रभात सर!"
            in 12..16 -> "शुभ दोपहर सर!"
            in 17..21 -> "शुभ संध्या सर!"
            else -> "नमस्ते सर!"
        }

        val spoken = "$greetingText जार्विस आपके आदेश के लिए तैयार है। बताइए मैं क्या सहायता करूँ?"
        val display = "🤖 $greetingText\n\nI am JARVIS. How may I assist you today, Sir?"

        return CommandResult(
            spokenResponseHindi = spoken,
            displayText = display,
            actionExecuted = "Greeting"
        )
    }

    private fun isIdentityCommand(query: String): Boolean {
        val triggers = listOf(
            "who are you", "your name", "tum kaun ho", "aap kaun ho", "tumhara naam", "aapka naam",
            "तुम कौन हो", "आप कौन हैं", "तुम्हारा नाम", "जार्विस क्या है"
        )
        return triggers.any { query.contains(it) }
    }

    private fun handleIdentity(): CommandResult {
        val spoken = "मैं जार्विस हूँ, आपका उन्नत कृत्रिम बुद्धिमत्ता सहायक। मैं आपके फोन के ऐप्स खोलने, समय, बैटरी और विभिन्न सवालों के जवाब देने में आपकी सहायता कर सकता हूँ।"
        val display = "🛡️ J.A.R.V.I.S. (Just A Rather Very Intelligent System)\n\n" +
                "I am your personal AI assistant. I can open apps, check device telemetry, answer questions, and control functions via Hindi & English voice commands."

        return CommandResult(
            spokenResponseHindi = spoken,
            displayText = display,
            actionExecuted = "Identity"
        )
    }

    private fun isHelpCommand(query: String): Boolean {
        val triggers = listOf(
            "help", "commands", "kya kar sakte ho", "features", "madad",
            "मदद", "कमांड्स", "क्या कर सकते हो", "सहायता"
        )
        return triggers.any { query.contains(it) }
    }

    private fun handleHelp(): CommandResult {
        val spoken = "सर, आप बोल सकते हैं: यूट्यूब खोलो, व्हाट्सएप खोलो, कैमरा खोलो, मैप्स खोलो, क्रोम खोलो, समय क्या है, या बैटरी कितनी है।"
        val display = "📋 Supported Commands:\n\n" +
                "• 'YouTube kholo' (Open YouTube)\n" +
                "• 'WhatsApp kholo' (Open WhatsApp)\n" +
                "• 'Camera kholo' (Launch Camera)\n" +
                "• 'Maps kholo' (Open Google Maps)\n" +
                "• 'Chrome kholo' (Launch Chrome Browser)\n" +
                "• 'Time kya hua hai' (Check Time)\n" +
                "• 'Battery kitni hai' (Check Battery)\n" +
                "• 'Ek joke sunao' (Tell a Joke)\n" +
                "• Math calculations like '25 + 75'"

        return CommandResult(
            spokenResponseHindi = spoken,
            displayText = display,
            actionExecuted = "Help"
        )
    }

    private fun isJokeCommand(query: String): Boolean {
        val triggers = listOf(
            "joke", "chutkula", "hasi", "fun",
            "जोक", "चुटकुला", "हंसी"
        )
        return triggers.any { query.contains(it) }
    }

    private fun handleJoke(): CommandResult {
        val jokes = listOf(
            Pair(
                "एक कंप्यूटर दूसरे कंप्यूटर से बोला: तुम इतनी तेज़ काम कैसे करते हो? दूसरा बोला: क्योंकि मेरे पास कोई इंसान नहीं है काम बिगाड़ने के लिए!",
                "😄 Tech Joke:\nA programmer goes to a store: 'Get a loaf of bread, and if they have eggs, get a dozen.' He returned with 12 loaves of bread."
            ),
            Pair(
                "डॉक्टर ने मरीज़ से कहा: आपको कंप्यूटर वायरस नहीं, सामान्य फ्लू हुआ है! मरीज़ बोला: तो फिर मेरा सिर रीस्टार्ट क्यों मांग रहा है?",
                "🤖 AI Humor:\nThere are 10 types of people in the world: those who understand binary, and those who don't."
            ),
            Pair(
                "टीचर: फोन का सबसे बड़ा फायदा क्या है? छात्र: सर, बिना पढ़े भी गूगल से टॉप कर सकते हैं!",
                "💡 Geek Humor:\nWhy do programmers prefer dark mode? Because light attracts bugs!"
            )
        )
        val selected = jokes.random()
        return CommandResult(
            spokenResponseHindi = selected.first,
            displayText = "${selected.second}\n\n${selected.first}",
            actionExecuted = "Told Joke"
        )
    }

    private fun tryEvaluateMath(query: String): CommandResult? {
        val mathPattern = Regex("""(\d+(?:\.\d+)?)\s*([\+\-\*\/xX]|plus|minus|into|divided by|bhaag|guna|jod|ghata)\s*(\d+(?:\.\d+)?)""")
        val match = mathPattern.find(query) ?: return null

        val (num1Str, opStr, num2Str) = match.destructured
        val num1 = num1Str.toDoubleOrNull() ?: return null
        val num2 = num2Str.toDoubleOrNull() ?: return null

        val result = when (opStr) {
            "+", "plus", "jod" -> num1 + num2
            "-", "minus", "ghata" -> num1 - num2
            "*", "x", "X", "into", "guna" -> num1 * num2
            "/", "divided by", "bhaag" -> if (num2 != 0.0) num1 / num2 else Double.NaN
            else -> return null
        }

        if (result.isNaN()) {
            return CommandResult(
                spokenResponseHindi = "शून्य से भाग नहीं दिया जा सकता, सर।",
                displayText = "⚠️ Division by zero is undefined.",
                isError = true
            )
        }

        val formattedResult = if (result % 1.0 == 0.0) result.toLong().toString() else "%.2f".format(result)
        val spoken = "सर, इसका उत्तर $formattedResult है।"
        val display = "🧮 Calculation: $num1Str $opStr $num2Str = $formattedResult\n\n$spoken"

        return CommandResult(
            spokenResponseHindi = spoken,
            displayText = display,
            actionExecuted = "Math: $formattedResult"
        )
    }

    private fun isSearchCommand(query: String): Boolean {
        val triggers = listOf(
            "search", "dhoondo", "khojo", "google karo", "search for",
            "सर्च", "ढूंढो", "खोजो", "गूगल करो"
        )
        return triggers.any { query.contains(it) }
    }

    private fun handleSearch(query: String): CommandResult {
        var cleanQuery = query
        val prefixes = listOf("search for", "search karo", "search", "google karo", "dhoondo", "सर्च करो", "ढूंढो")
        for (p in prefixes) {
            cleanQuery = cleanQuery.replace(p, "").trim()
        }
        if (cleanQuery.isBlank()) cleanQuery = "JARVIS AI Assistant"

        val searchUri = Uri.parse("https://www.google.com/search?q=${Uri.encode(cleanQuery)}")
        val intent = Intent(Intent.ACTION_VIEW, searchUri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        val spoken = "सर, '$cleanQuery' के लिए वेब पर खोज की जा रही है।"
        val display = "🔍 Searching Google for '$cleanQuery'...\n\n$spoken"

        return CommandResult(
            spokenResponseHindi = spoken,
            displayText = display,
            actionExecuted = "Search: $cleanQuery",
            launchIntent = intent
        )
    }

    private fun handleGeneralQuery(query: String): CommandResult {
        val spoken = "सर, मैंने आपका संदेश समझ लिया: '$query'। मैं इसके लिए तैयार हूँ।"
        val display = "💡 Question: \"$query\"\n\n" +
                "सर, मैं एक ऑफलाइन और सुरक्षित सहायक के रूप में वर्तमान में ऐप्स खोलने, डिवाइस की स्थिति जांचने, गणितीय गणना और सामान्य प्रश्नों के उत्तर देने के लिए सक्रिय हूँ।"

        return CommandResult(
            spokenResponseHindi = spoken,
            displayText = display,
            actionExecuted = "General Query"
        )
    }
}
