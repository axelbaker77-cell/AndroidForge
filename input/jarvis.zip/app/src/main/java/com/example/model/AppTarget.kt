package com.example.model

data class AppTarget(
    val id: String,
    val nameEn: String,
    val nameHi: String,
    val packageName: String,
    val keywords: List<String>,
    val hindiKeywords: List<String>,
    val playStorePackage: String = packageName,
    val fallbackAction: String? = null,
    val description: String
)

object SupportedApps {
    val YOUTUBE = AppTarget(
        id = "youtube",
        nameEn = "YouTube",
        nameHi = "यूट्यूब",
        packageName = "com.google.android.youtube",
        keywords = listOf("youtube", "yt", "you tube", "video"),
        hindiKeywords = listOf("यूट्यूब", "युटुब", "विडियो", "वीडियो"),
        fallbackAction = "https://www.youtube.com",
        description = "Videos and music streaming"
    )

    val WHATSAPP = AppTarget(
        id = "whatsapp",
        nameEn = "WhatsApp",
        nameHi = "व्हाट्सएप",
        packageName = "com.whatsapp",
        keywords = listOf("whatsapp", "whats app", "chat"),
        hindiKeywords = listOf("व्हाट्सएप", "व्हाट्सऐप", "वाट्सएप", "चैट"),
        description = "Messaging and calling"
    )

    val CAMERA = AppTarget(
        id = "camera",
        nameEn = "Camera",
        nameHi = "कैमरा",
        packageName = "android.hardware.camera2",
        keywords = listOf("camera", "photo", "picture", "selfie", "cam"),
        hindiKeywords = listOf("कैमरा", "फोटो", "तस्वीर", "पिक्चर"),
        fallbackAction = "android.media.action.IMAGE_CAPTURE",
        description = "Photo and video recording"
    )

    val MAPS = AppTarget(
        id = "maps",
        nameEn = "Google Maps",
        nameHi = "गूगल मैप्स",
        packageName = "com.google.android.apps.maps",
        keywords = listOf("maps", "map", "navigation", "route", "location"),
        hindiKeywords = listOf("मैप्स", "मैप", "नक्शा", "रास्ता", "लोकेशन"),
        fallbackAction = "geo:0,0?q=",
        description = "Navigation and location exploration"
    )

    val CHROME = AppTarget(
        id = "chrome",
        nameEn = "Google Chrome",
        nameHi = "गूगल क्रोम",
        packageName = "com.android.chrome",
        keywords = listOf("chrome", "browser", "internet", "web"),
        hindiKeywords = listOf("क्रोम", "ब्राउज़र", "इंटरनेट", "वेब"),
        fallbackAction = "https://www.google.com",
        description = "Web browsing and search"
    )

    val CALCULATOR = AppTarget(
        id = "calculator",
        nameEn = "Calculator",
        nameHi = "कैलकुलेटर",
        packageName = "com.google.android.calculator",
        keywords = listOf("calculator", "calc", "math"),
        hindiKeywords = listOf("कैलकुलेटर", "हिसाब"),
        description = "Math and calculations"
    )

    val CLOCK = AppTarget(
        id = "clock",
        nameEn = "Clock & Alarm",
        nameHi = "घड़ी और अलार्म",
        packageName = "com.google.android.deskclock",
        keywords = listOf("clock", "alarm", "timer", "stopwatch"),
        hindiKeywords = listOf("घड़ी", "अलार्म", "समय", "टाइमर"),
        fallbackAction = "android.intent.action.SHOW_ALARMS",
        description = "Time, alarms and timer"
    )

    val GMAIL = AppTarget(
        id = "gmail",
        nameEn = "Gmail",
        nameHi = "जीमेल",
        packageName = "com.google.android.gm",
        keywords = listOf("gmail", "email", "mail"),
        hindiKeywords = listOf("जीमेल", "ईमेल", "मेल"),
        fallbackAction = "mailto:",
        description = "Email correspondence"
    )

    val SPOTIFY = AppTarget(
        id = "spotify",
        nameEn = "Spotify",
        nameHi = "स्पॉटिफाई",
        packageName = "com.spotify.music",
        keywords = listOf("spotify", "music", "song", "songs"),
        hindiKeywords = listOf("स्पॉटिफाई", "म्यूजिक", "गाना", "गाने"),
        description = "Music and podcast streaming"
    )

    val allApps = listOf(
        YOUTUBE,
        WHATSAPP,
        CAMERA,
        MAPS,
        CHROME,
        CALCULATOR,
        CLOCK,
        GMAIL,
        SPOTIFY
    )
}
