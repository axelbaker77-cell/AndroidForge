package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic Dark Blue & Cyan Neon Palette for JARVIS
val DeepSpaceBackground = Color(0xFF050B18)
val DarkSurface = Color(0xFF0B1428)
val DarkSurfaceVariant = Color(0xFF101E3C)
val DarkContainer = Color(0xFF14244B)

// Neon & Holographic Accents
val NeonCyanPrimary = Color(0xFF00E5FF)
val NeonCyanVariant = Color(0xFF00B4D8)
val NeonSkySecondary = Color(0xFF38BDF8)
val ElectricBlue = Color(0xFF1E88E5)
val HolographicTeal = Color(0xFF00F5D4)
val CyberPurple = Color(0xFF818CF8)

// Status & Functional Colors
val CyberGreen = Color(0xFF00E676)
val CyberAmber = Color(0xFFFFB300)
val CyberRed = Color(0xFFFF3366)

// Text & Content Colors
val TextWhitePrimary = Color(0xFFF1F5F9)
val TextCyanSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val BorderCyanGlow = Color(0x6600E5FF)
val BorderDark = Color(0xFF1E293B)
