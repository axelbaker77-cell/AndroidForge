package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.CommandResult
import com.example.engine.JarvisCommandEngine
import com.example.model.AppTarget
import com.example.model.AssistantTab
import com.example.model.ChatMessage
import com.example.model.SenderType
import com.example.model.SupportedApps
import com.example.model.VoiceLanguage
import com.example.model.VoiceState
import com.example.speech.JarvisSpeechManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class JarvisUiState(
    val messages: List<ChatMessage> = emptyList(),
    val voiceState: VoiceState = VoiceState.Idle,
    val currentTab: AssistantTab = AssistantTab.CORE_HUD,
    val selectedLanguage: VoiceLanguage = VoiceLanguage.HINDI_ENGLISH,
    val isMuted: Boolean = false,
    val installedAppsMap: Map<String, Boolean> = emptyMap(),
    val lastTranscript: String = "",
    val batteryPct: Int = 100,
    val isCharging: Boolean = false,
    val showHelpDialog: Boolean = false
)

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    private val commandEngine = JarvisCommandEngine(application.applicationContext)
    private var speechManager: JarvisSpeechManager? = null

    private val _uiState = MutableStateFlow(JarvisUiState())
    val uiState = _uiState.asStateFlow()

    // One-off side effects like launching an Activity intent
    private val _launchIntentEvent = MutableSharedFlow<Intent>(extraBufferCapacity = 1)
    val launchIntentEvent = _launchIntentEvent.asSharedFlow()

    init {
        initSpeechManager()
        refreshInstalledApps()
        refreshBatteryStatus()
        addInitialJarvisGreeting()
    }

    private fun initSpeechManager() {
        speechManager = JarvisSpeechManager(
            context = getApplication<Application>().applicationContext,
            onVoiceRmsChanged = { rms ->
                if (_uiState.value.voiceState is VoiceState.Listening) {
                    _uiState.value = _uiState.value.copy(
                        voiceState = VoiceState.Listening(rms)
                    )
                }
            },
            onSpeechResult = { recognizedText ->
                processSpeechInput(recognizedText)
            },
            onSpeechError = { errorMessage ->
                _uiState.value = _uiState.value.copy(
                    voiceState = VoiceState.Error(errorMessage),
                    lastTranscript = errorMessage
                )
                viewModelScope.launch {
                    delay(3500)
                    if (_uiState.value.voiceState is VoiceState.Error) {
                        _uiState.value = _uiState.value.copy(voiceState = VoiceState.Idle)
                    }
                }
            },
            onTtsStart = {
                // Keep voice state updated
            },
            onTtsDone = {
                if (_uiState.value.voiceState is VoiceState.Speaking) {
                    _uiState.value = _uiState.value.copy(voiceState = VoiceState.Idle)
                }
            }
        )
    }

    private fun addInitialJarvisGreeting() {
        val initialGreeting = ChatMessage(
            text = "नमस्ते सर, मैं जार्विस हूँ! मैं आपके वॉइस और चैट कमांड्स के लिए तैयार हूँ।\n" +
                    "बोलिए 'YouTube kholo', 'WhatsApp kholo', 'Camera kholo', 'Maps kholo' या 'Chrome kholo'!",
            sender = SenderType.JARVIS,
            actionExecuted = "System Online"
        )
        _uiState.value = _uiState.value.copy(
            messages = listOf(initialGreeting),
            lastTranscript = "JARVIS Online. Speak or type a command."
        )
    }

    fun refreshInstalledApps() {
        val pm = getApplication<Application>().packageManager
        val map = mutableMapOf<String, Boolean>()
        for (app in SupportedApps.allApps) {
            val isInstalled = if (app.id == "camera") {
                val intent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
                intent.resolveActivity(pm) != null
            } else {
                pm.getLaunchIntentForPackage(app.packageName) != null
            }
            map[app.id] = isInstalled
        }
        _uiState.value = _uiState.value.copy(installedAppsMap = map)
    }

    fun refreshBatteryStatus() {
        val context = getApplication<Application>().applicationContext
        val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus: Intent? = context.registerReceiver(null, ifilter)

        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
        val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else 85

        _uiState.value = _uiState.value.copy(
            batteryPct = batteryPct,
            isCharging = isCharging
        )
    }

    fun setTab(tab: AssistantTab) {
        _uiState.value = _uiState.value.copy(currentTab = tab)
        if (tab == AssistantTab.SYSTEM_STATUS) {
            refreshInstalledApps()
            refreshBatteryStatus()
        }
    }

    fun toggleMute() {
        val newMute = !_uiState.value.isMuted
        if (newMute) {
            speechManager?.stopSpeaking()
        }
        _uiState.value = _uiState.value.copy(isMuted = newMute)
    }

    fun setLanguage(language: VoiceLanguage) {
        _uiState.value = _uiState.value.copy(selectedLanguage = language)
    }

    fun setShowHelp(show: Boolean) {
        _uiState.value = _uiState.value.copy(showHelpDialog = show)
    }

    fun toggleVoiceListening() {
        val currentState = _uiState.value.voiceState
        if (currentState is VoiceState.Listening) {
            // User taps mic while listening -> stop
            speechManager?.stopListening()
            _uiState.value = _uiState.value.copy(voiceState = VoiceState.Idle)
        } else if (currentState is VoiceState.Speaking) {
            // User taps mic while speaking -> stop speech and start listening
            speechManager?.stopSpeaking()
            startListening()
        } else {
            startListening()
        }
    }

    fun startListening() {
        _uiState.value = _uiState.value.copy(
            voiceState = VoiceState.Listening(0f),
            lastTranscript = "कमांड सुन रहा हूँ... (Listening...)"
        )
        speechManager?.startListening(_uiState.value.selectedLanguage.code)
    }

    fun stopListening() {
        speechManager?.stopListening()
        _uiState.value = _uiState.value.copy(voiceState = VoiceState.Idle)
    }

    private fun processSpeechInput(recognizedText: String) {
        _uiState.value = _uiState.value.copy(
            voiceState = VoiceState.Processing(recognizedText),
            lastTranscript = "\"$recognizedText\""
        )
        executeUserInput(recognizedText)
    }

    fun executeUserInput(inputText: String) {
        val trimmed = inputText.trim()
        if (trimmed.isEmpty()) return

        // 1. Add User message to chat
        val userMsg = ChatMessage(
            text = trimmed,
            sender = SenderType.USER
        )
        val currentMessages = _uiState.value.messages.toMutableList()
        currentMessages.add(userMsg)
        _uiState.value = _uiState.value.copy(messages = currentMessages)

        // 2. Execute via CommandEngine
        val result: CommandResult = commandEngine.executeQuery(trimmed)

        // 3. Create JARVIS ChatMessage
        val jarvisMsg = ChatMessage(
            text = result.displayText,
            sender = SenderType.JARVIS,
            actionExecuted = result.actionExecuted,
            isAppLaunch = result.isAppLaunch,
            isError = result.isError,
            playStorePackage = result.playStorePackage
        )
        currentMessages.add(jarvisMsg)

        _uiState.value = _uiState.value.copy(
            messages = currentMessages,
            voiceState = VoiceState.Speaking(result.spokenResponseHindi),
            lastTranscript = result.actionExecuted ?: result.displayText
        )

        // 4. Speak response aloud in Hindi
        speechManager?.speak(result.spokenResponseHindi, _uiState.value.isMuted)

        // 5. Fire Launch Intent if present
        if (result.launchIntent != null) {
            viewModelScope.launch {
                delay(600) // slight delay for smooth transition
                _launchIntentEvent.tryEmit(result.launchIntent)
            }
        }
    }

    fun speakMessage(text: String) {
        _uiState.value = _uiState.value.copy(voiceState = VoiceState.Speaking(text))
        speechManager?.speak(text, isMuted = false)
    }

    fun launchAppDirectly(app: AppTarget) {
        executeUserInput("${app.nameEn} kholo")
    }

    override fun onCleared() {
        super.onCleared()
        speechManager?.destroy()
    }
}
