package com.example.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.AssistantTab
import com.example.ui.components.JarvisBottomNav
import com.example.ui.components.JarvisHelpDialog
import com.example.ui.components.JarvisTopBar
import com.example.ui.screens.JarvisAppStatusScreen
import com.example.ui.screens.JarvisChatScreen
import com.example.ui.screens.JarvisCommandMatrixScreen
import com.example.ui.screens.JarvisHUDView
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.DarkContainer
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DeepSpaceBackground
import com.example.ui.theme.NeonCyanPrimary
import com.example.ui.theme.NeonSkySecondary
import com.example.ui.theme.TextCyanSecondary
import com.example.ui.theme.TextWhitePrimary
import com.example.viewmodel.JarvisViewModel
import kotlinx.coroutines.launch

@Composable
fun JarvisMainContainer(
    viewModel: JarvisViewModel = viewModel(),
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var showPermissionDialog by remember { mutableStateOf(false) }

    // Central Audio Permission Launcher
    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.toggleVoiceListening()
        } else {
            showPermissionDialog = true
        }
    }

    fun requestVoiceListening() {
        val hasAudioPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasAudioPermission) {
            viewModel.toggleVoiceListening()
        } else {
            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    // Handle back button: if in a secondary tab, return to CORE_HUD
    BackHandler(enabled = uiState.currentTab != AssistantTab.CORE_HUD) {
        viewModel.setTab(AssistantTab.CORE_HUD)
    }

    // Collect app launch events
    LaunchedEffect(Unit) {
        viewModel.launchIntentEvent.collect { intent ->
            try {
                context.startActivity(intent)
            } catch (e: Exception) {
                scope.launch {
                    snackbarHostState.showSnackbar("Unable to launch activity: ${e.localizedMessage}")
                }
            }
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(DeepSpaceBackground)
            .statusBarsPadding(),
        topBar = {
            JarvisTopBar(
                batteryPct = uiState.batteryPct,
                isCharging = uiState.isCharging,
                isMuted = uiState.isMuted,
                selectedLanguage = uiState.selectedLanguage,
                onToggleMute = { viewModel.toggleMute() },
                onSelectLanguage = { viewModel.setLanguage(it) },
                onOpenHelp = { viewModel.setShowHelp(true) }
            )
        },
        bottomBar = {
            JarvisBottomNav(
                currentTab = uiState.currentTab,
                onTabSelected = { viewModel.setTab(it) }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = DeepSpaceBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (uiState.currentTab) {
                AssistantTab.CORE_HUD -> {
                    JarvisHUDView(
                        voiceState = uiState.voiceState,
                        lastTranscript = uiState.lastTranscript,
                        onMicTapped = { requestVoiceListening() },
                        onPermissionDenied = { showPermissionDialog = true },
                        onSelectCommand = { command ->
                            viewModel.executeUserInput(command)
                        },
                        onNavigateToChat = {
                            viewModel.setTab(AssistantTab.CHAT)
                        }
                    )
                }

                AssistantTab.CHAT -> {
                    JarvisChatScreen(
                        messages = uiState.messages,
                        voiceState = uiState.voiceState,
                        onSendMessage = { text ->
                            viewModel.executeUserInput(text)
                        },
                        onSpeakMessage = { text ->
                            viewModel.speakMessage(text)
                        },
                        onMicTapped = {
                            requestVoiceListening()
                        }
                    )
                }

                AssistantTab.COMMANDS -> {
                    JarvisCommandMatrixScreen(
                        onTestCommand = { testQuery ->
                            viewModel.executeUserInput(testQuery)
                        }
                    )
                }

                AssistantTab.SYSTEM_STATUS -> {
                    JarvisAppStatusScreen(
                        installedAppsMap = uiState.installedAppsMap,
                        onRefresh = {
                            viewModel.refreshInstalledApps()
                            viewModel.refreshBatteryStatus()
                        },
                        onLaunchApp = { app ->
                            viewModel.launchAppDirectly(app)
                        }
                    )
                }
            }

            // Help & APK Guide Modal Dialog
            if (uiState.showHelpDialog) {
                JarvisHelpDialog(
                    onDismiss = { viewModel.setShowHelp(false) }
                )
            }

            // Explicit Permission Explanation Dialog
            if (showPermissionDialog) {
                Dialog(onDismissRequest = { showPermissionDialog = false }) {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkContainer),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, BorderCyanGlow, RoundedCornerShape(18.dp))
                            .padding(4.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(DarkSurfaceVariant, RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = null,
                                    tint = CyberAmber,
                                    modifier = Modifier.size(28.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = "माइक अनुमति आवश्यक है\nMicrophone Permission Required",
                                color = NeonCyanPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "JARVIS needs microphone access to listen to your voice commands in Hindi and English. Your privacy is guaranteed: audio is never recorded in the background or sent to third-party servers.",
                                color = TextWhitePrimary,
                                fontSize = 13.sp,
                                lineHeight = 18.sp
                            )

                            Spacer(modifier = Modifier.height(18.dp))

                            Button(
                                onClick = {
                                    showPermissionDialog = false
                                    audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonCyanPrimary),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("grant_permission_button")
                            ) {
                                Text(
                                    text = "Grant Permission",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedButton(
                                onClick = {
                                    showPermissionDialog = false
                                    try {
                                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                            data = Uri.fromParts("package", context.packageName, null)
                                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        }
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Could not open settings", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("open_settings_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = null,
                                    tint = NeonSkySecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Open App Settings",
                                    color = NeonSkySecondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
