package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppTarget
import com.example.model.SupportedApps
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.DarkContainer
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DeepSpaceBackground
import com.example.ui.theme.NeonCyanPrimary
import com.example.ui.theme.NeonSkySecondary
import com.example.ui.theme.TextCyanSecondary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhitePrimary

@Composable
fun JarvisAppStatusScreen(
    installedAppsMap: Map<String, Boolean>,
    onRefresh: () -> Unit,
    onLaunchApp: (AppTarget) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DeepSpaceBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "APP DIAGNOSTICS & STATUS",
                        color = NeonCyanPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Real-time installed app status for voice intents",
                        color = TextCyanSecondary,
                        fontSize = 12.sp
                    )
                }

                IconButton(
                    onClick = onRefresh,
                    modifier = Modifier.testTag("refresh_diagnostics_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh app status",
                        tint = NeonCyanPrimary
                    )
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkContainer),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderCyanGlow.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val installedCount = SupportedApps.allApps.count { installedAppsMap[it.id] == true }
                    val total = SupportedApps.allApps.size

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "AVAILABLE APPS: $installedCount / $total",
                            color = NeonSkySecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "If an app is missing, JARVIS provides a 1-tap Play Store installation link.",
                            color = TextCyanSecondary,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        items(SupportedApps.allApps, key = { it.id }) { app ->
            val isInstalled = installedAppsMap[app.id] == true
            AppStatusRow(
                app = app,
                isInstalled = isInstalled,
                onLaunch = { onLaunchApp(app) },
                onInstall = {
                    try {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${app.playStorePackage}")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=${app.playStorePackage}")).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(webIntent)
                    }
                }
            )
        }
    }
}

@Composable
fun AppStatusRow(
    app: AppTarget,
    isInstalled: Boolean,
    onLaunch: () -> Unit,
    onInstall: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isInstalled) CyberGreen.copy(alpha = 0.4f) else CyberAmber.copy(alpha = 0.4f),
                RoundedCornerShape(12.dp)
            )
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(if (isInstalled) CyberGreen else CyberAmber)
            )

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = app.nameEn,
                        color = TextWhitePrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "(${app.nameHi})",
                        color = NeonCyanPrimary,
                        fontSize = 11.sp
                    )
                }
                Text(
                    text = if (isInstalled) "Status: Installed & Ready" else "Status: Not installed on device",
                    color = if (isInstalled) CyberGreen else CyberAmber,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            if (isInstalled) {
                Button(
                    onClick = onLaunch,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyanPrimary),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("launch_app_${app.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Launch,
                        contentDescription = "Launch ${app.nameEn}",
                        tint = Color.Black,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Open",
                        color = Color.Black,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                Button(
                    onClick = onInstall,
                    colors = ButtonDefaults.buttonColors(containerColor = CyberAmber),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("install_app_${app.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Shop,
                        contentDescription = "Install ${app.nameEn}",
                        tint = Color.Black,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Install",
                        color = Color.Black,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
