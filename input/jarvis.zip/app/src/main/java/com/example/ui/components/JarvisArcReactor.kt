package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.VoiceState
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberRed
import com.example.ui.theme.DarkContainer
import com.example.ui.theme.HolographicTeal
import com.example.ui.theme.NeonCyanPrimary
import com.example.ui.theme.NeonCyanVariant
import com.example.ui.theme.NeonSkySecondary
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun JarvisArcReactor(
    voiceState: VoiceState,
    modifier: Modifier = Modifier,
    size: Dp = 220.dp
) {
    val transition = rememberInfiniteTransition(label = "arc_reactor")

    // Slow continuous outer rotation
    val outerRotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outer_rot"
    )

    // Reverse middle rotation
    val middleRotation by transition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "middle_rot"
    )

    // Pulsing inner glow
    val pulseScale by transition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val coreColor = when (voiceState) {
        is VoiceState.Listening -> CyberGreen
        is VoiceState.Speaking -> NeonCyanPrimary
        is VoiceState.Processing -> CyberPurple
        is VoiceState.Error -> CyberRed
        VoiceState.Idle -> NeonCyanPrimary
    }

    val rmsDb = if (voiceState is VoiceState.Listening) voiceState.rmsDb else 0f
    val dynamicRmsBoost = (rmsDb / 10f).coerceIn(0f, 1.5f)

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val baseRadius = this.size.minDimension / 2f * 0.9f

            // 1. Outermost subtle ambient glow circle
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        coreColor.copy(alpha = 0.35f + (dynamicRmsBoost * 0.2f)),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * 1.15f
                ),
                radius = baseRadius * 1.15f,
                center = center
            )

            // 2. Outer segmented tech ring
            rotate(outerRotation, pivot = center) {
                val segments = 8
                val sweepAngle = 26f
                val gap = 360f / segments
                for (i in 0 until segments) {
                    val startAngle = i * gap
                    drawArc(
                        color = NeonSkySecondary.copy(alpha = 0.65f),
                        startAngle = startAngle,
                        sweepAngle = sweepAngle,
                        useCenter = false,
                        topLeft = Offset(center.x - baseRadius, center.y - baseRadius),
                        size = Size(baseRadius * 2, baseRadius * 2),
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                // Tick marks
                val ticks = 32
                for (i in 0 until ticks) {
                    val angleRad = Math.toRadians((i * (360.0 / ticks)))
                    val r1 = baseRadius - 10.dp.toPx()
                    val r2 = baseRadius - 4.dp.toPx()
                    val p1 = Offset(
                        (center.x + r1 * cos(angleRad)).toFloat(),
                        (center.y + r1 * sin(angleRad)).toFloat()
                    )
                    val p2 = Offset(
                        (center.x + r2 * cos(angleRad)).toFloat(),
                        (center.y + r2 * sin(angleRad)).toFloat()
                    )
                    drawLine(
                        color = NeonCyanVariant.copy(alpha = if (i % 4 == 0) 0.8f else 0.3f),
                        start = p1,
                        end = p2,
                        strokeWidth = if (i % 4 == 0) 2.dp.toPx() else 1.dp.toPx()
                    )
                }
            }

            // 3. Middle counter-rotating ring
            val midRadius = baseRadius * 0.72f
            rotate(middleRotation, pivot = center) {
                // Outer mid-circle
                drawCircle(
                    color = BorderCyanGlow,
                    radius = midRadius,
                    center = center,
                    style = Stroke(width = 1.5.dp.toPx())
                )

                // 3 segmented heavy arcs
                for (i in 0 until 3) {
                    val startAngle = i * 120f + 15f
                    drawArc(
                        color = coreColor,
                        startAngle = startAngle,
                        sweepAngle = 70f,
                        useCenter = false,
                        topLeft = Offset(center.x - midRadius, center.y - midRadius),
                        size = Size(midRadius * 2, midRadius * 2),
                        style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            // 4. Equalizer Waveform bars around inner core
            val innerRingRadius = baseRadius * 0.48f
            val barCount = 24
            for (i in 0 until barCount) {
                val angleRad = Math.toRadians(i * (360.0 / barCount) + outerRotation * 0.5)
                val baseBarLen = 5.dp.toPx()
                val waveBoost = if (voiceState is VoiceState.Listening || voiceState is VoiceState.Speaking) {
                    val variation = sin(i * 0.8 + outerRotation * 0.1).toFloat() * 10.dp.toPx()
                    baseBarLen + variation + (dynamicRmsBoost * 14.dp.toPx())
                } else {
                    baseBarLen
                }
                val rStart = innerRingRadius
                val rEnd = innerRingRadius + waveBoost.coerceAtLeast(3.dp.toPx())

                val start = Offset(
                    (center.x + rStart * cos(angleRad)).toFloat(),
                    (center.y + rStart * sin(angleRad)).toFloat()
                )
                val end = Offset(
                    (center.x + rEnd * cos(angleRad)).toFloat(),
                    (center.y + rEnd * sin(angleRad)).toFloat()
                )
                drawLine(
                    color = HolographicTeal.copy(alpha = 0.8f),
                    start = start,
                    end = end,
                    strokeWidth = 2.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // 5. Inner Arc Reactor Core
            val coreRadius = baseRadius * 0.36f * (if (voiceState is VoiceState.Listening) pulseScale + dynamicRmsBoost * 0.1f else pulseScale)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White,
                        coreColor,
                        DarkContainer
                    ),
                    center = center,
                    radius = coreRadius
                ),
                radius = coreRadius,
                center = center
            )

            // Inner circle stroke
            drawCircle(
                color = Color.White.copy(alpha = 0.8f),
                radius = coreRadius * 0.6f,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )

            // Center glowing dot
            drawCircle(
                color = Color.White,
                radius = 4.dp.toPx(),
                center = center
            )
        }
    }
}
