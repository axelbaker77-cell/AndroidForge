package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.model.VoiceState
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberRed
import com.example.ui.theme.DarkContainer
import com.example.ui.theme.NeonCyanPrimary
import com.example.ui.theme.NeonCyanVariant

@Composable
fun JarvisMicButton(
    voiceState: VoiceState,
    onMicTapped: () -> Unit,
    onPermissionDenied: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 76.dp
) {
    val context = LocalContext.current

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            onMicTapped()
        } else {
            onPermissionDenied()
        }
    }

    val isListening = voiceState is VoiceState.Listening
    val isSpeaking = voiceState is VoiceState.Speaking

    val transition = rememberInfiniteTransition(label = "mic_pulse")
    val pulseScale by transition.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening) 1.25f else 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (isListening) 800 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "mic_scale"
    )

    val activeColor = when (voiceState) {
        is VoiceState.Listening -> CyberGreen
        is VoiceState.Speaking -> NeonCyanPrimary
        is VoiceState.Processing -> CyberPurple
        is VoiceState.Error -> CyberRed
        VoiceState.Idle -> NeonCyanPrimary
    }

    Box(
        modifier = modifier.size(size + 24.dp),
        contentAlignment = Alignment.Center
    ) {
        // Outer pulsing ring when active
        if (isListening || isSpeaking) {
            Box(
                modifier = Modifier
                    .size(size + 20.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .border(
                        width = 2.dp,
                        color = activeColor.copy(alpha = 0.5f),
                        shape = CircleShape
                    )
            )
        }

        // Main Core Mic Button
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            activeColor.copy(alpha = if (isListening) 0.9f else 0.35f),
                            DarkContainer
                        )
                    )
                )
                .border(
                    width = 2.dp,
                    color = activeColor,
                    shape = CircleShape
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(bounded = true, color = activeColor)
                ) {
                    val hasAudioPermission = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.RECORD_AUDIO
                    ) == PackageManager.PERMISSION_GRANTED

                    if (hasAudioPermission) {
                        onMicTapped()
                    } else {
                        // Request permission only on-demand when user taps mic
                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                }
                .testTag("jarvis_mic_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                contentDescription = if (isListening) "Stop voice listening" else "Start voice command in Hindi or English",
                tint = if (isListening) Color.Black else activeColor,
                modifier = Modifier.size(size * 0.45f)
            )
        }
    }
}
