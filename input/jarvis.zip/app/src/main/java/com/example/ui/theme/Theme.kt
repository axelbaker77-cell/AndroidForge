package com.example.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val JarvisDarkColorScheme = darkColorScheme(
    primary = NeonCyanPrimary,
    onPrimary = Color(0xFF021020),
    primaryContainer = DarkContainer,
    onPrimaryContainer = NeonCyanPrimary,
    secondary = NeonSkySecondary,
    onSecondary = Color(0xFF03142B),
    secondaryContainer = DarkSurfaceVariant,
    onSecondaryContainer = NeonSkySecondary,
    tertiary = HolographicTeal,
    onTertiary = Color(0xFF002B24),
    background = DeepSpaceBackground,
    onBackground = TextWhitePrimary,
    surface = DarkSurface,
    onSurface = TextWhitePrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextCyanSecondary,
    outline = BorderDark,
    outlineVariant = BorderCyanGlow,
    error = CyberRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Futuristic dark theme by default
    dynamicColor: Boolean = false, // Keep consistent cyber aesthetic
    content: @Composable () -> Unit
) {
    val colorScheme = JarvisDarkColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = DeepSpaceBackground.toArgb()
                window.navigationBarColor = DeepSpaceBackground.toArgb()
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = false
                    isAppearanceLightNavigationBars = false
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
