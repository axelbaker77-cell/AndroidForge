package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.DarkContainer
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DeepSpaceBackground
import com.example.ui.theme.NeonCyanPrimary
import com.example.ui.theme.NeonSkySecondary
import com.example.ui.theme.TextCyanSecondary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhitePrimary

data class CommandItem(
    val hindiPhrase: String,
    val englishPhrase: String,
    val description: String,
    val icon: ImageVector,
    val testQuery: String
)

@Composable
fun JarvisCommandMatrixScreen(
    onTestCommand: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val appCommands = listOf(
        CommandItem(
            hindiPhrase = "यूट्यूब खोलो",
            englishPhrase = "YouTube kholo / Open YouTube",
            description = "Launches YouTube app using Android intents",
            icon = Icons.Default.PlayArrow,
            testQuery = "YouTube kholo"
        ),
        CommandItem(
            hindiPhrase = "व्हाट्सएप खोलो",
            englishPhrase = "WhatsApp kholo / Open WhatsApp",
            description = "Launches WhatsApp or provides Play Store link if not installed",
            icon = Icons.Default.Chat,
            testQuery = "WhatsApp kholo"
        ),
        CommandItem(
            hindiPhrase = "कैमरा खोलो",
            englishPhrase = "Camera kholo / Open Camera",
            description = "Opens device camera to capture photos",
            icon = Icons.Default.CameraAlt,
            testQuery = "Camera kholo"
        ),
        CommandItem(
            hindiPhrase = "मैप्स खोलो",
            englishPhrase = "Maps kholo / Open Maps",
            description = "Opens Google Maps navigation intent",
            icon = Icons.Default.Map,
            testQuery = "Maps kholo"
        ),
        CommandItem(
            hindiPhrase = "क्रोम खोलो",
            englishPhrase = "Chrome kholo / Open Chrome",
            description = "Launches Google Chrome or standard web browser",
            icon = Icons.Default.Language,
            testQuery = "Chrome kholo"
        )
    )

    val systemCommands = listOf(
        CommandItem(
            hindiPhrase = "समय क्या हुआ है?",
            englishPhrase = "Time kya hua hai / What time is it?",
            description = "Reports exact live time formatted in Hindi",
            icon = Icons.Default.Schedule,
            testQuery = "Time kya hua hai"
        ),
        CommandItem(
            hindiPhrase = "बैटरी कितनी है?",
            englishPhrase = "Battery kitni hai / Check battery",
            description = "Queries device BatteryManager and speaks status in Hindi",
            icon = Icons.Default.Security,
            testQuery = "Battery kitni hai"
        ),
        CommandItem(
            hindiPhrase = "आज की तारीख क्या है?",
            englishPhrase = "Aaj ki date kya hai / Today's date",
            description = "Answers with current day and date in Hindi",
            icon = Icons.Default.Info,
            testQuery = "Aaj kaun sa din hai"
        )
    )

    val qaCommands = listOf(
        CommandItem(
            hindiPhrase = "तुम कौन हो?",
            englishPhrase = "Who are you? / Aap kaun ho?",
            description = "Introduces JARVIS cybernetic system identity",
            icon = Icons.Default.Apps,
            testQuery = "Tum kaun ho"
        ),
        CommandItem(
            hindiPhrase = "एक जोक सुनाओ",
            englishPhrase = "Ek joke sunao / Tell me a joke",
            description = "Shares tech and AI humor in Hindi and English",
            icon = Icons.Default.Mood,
            testQuery = "Ek joke sunao"
        ),
        CommandItem(
            hindiPhrase = "गणित (Math) गणना",
            englishPhrase = "50 + 25 kitna hoga / 12 * 8",
            description = "Evaluates math arithmetic equations offline",
            icon = Icons.Default.Calculate,
            testQuery = "50 + 25 kitna hoga"
        ),
        CommandItem(
            hindiPhrase = "गूगल पर सर्च करो",
            englishPhrase = "Search karo Android Compose",
            description = "Triggers Google search intent with voice query",
            icon = Icons.Default.Search,
            testQuery = "Search Android Jetpack Compose"
        )
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DeepSpaceBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "VOICE COMMAND MATRIX",
                color = NeonCyanPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
            Text(
                text = "Tap 'Test Command' on any card to test the voice response in Hindi.",
                color = TextCyanSecondary,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        // Section 1: App Launching
        item {
            SectionHeader(title = "CORE APP LAUNCHERS", count = appCommands.size)
        }
        items(appCommands.size) { index ->
            CommandCardItem(
                command = appCommands[index],
                onTest = { onTestCommand(appCommands[index].testQuery) }
            )
        }

        // Section 2: System Telemetry
        item {
            Spacer(modifier = Modifier.height(8.dp))
            SectionHeader(title = "DEVICE TELEMETRY", count = systemCommands.size)
        }
        items(systemCommands.size) { index ->
            CommandCardItem(
                command = systemCommands[index],
                onTest = { onTestCommand(systemCommands[index].testQuery) }
            )
        }

        // Section 3: Smart Q&A & Math
        item {
            Spacer(modifier = Modifier.height(8.dp))
            SectionHeader(title = "INTELLIGENT Q&A & UTILITIES", count = qaCommands.size)
        }
        items(qaCommands.size) { index ->
            CommandCardItem(
                command = qaCommands[index],
                onTest = { onTestCommand(qaCommands[index].testQuery) }
            )
        }
    }
}

@Composable
fun SectionHeader(title: String, count: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            color = NeonSkySecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )
        Text(
            text = "[$count COMMANDS]",
            color = TextMuted,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun CommandCardItem(
    command: CommandItem,
    onTest: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, BorderCyanGlow.copy(alpha = 0.35f), RoundedCornerShape(14.dp)),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkContainer)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkSurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = command.icon,
                        contentDescription = null,
                        tint = NeonCyanPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = command.englishPhrase,
                        color = TextWhitePrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "हिन्दी: \"${command.hindiPhrase}\"",
                        color = NeonCyanPrimary,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = command.description,
                color = TextCyanSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = onTest,
                colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, NeonCyanPrimary.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                    .testTag("test_command_${command.testQuery.replace(" ", "_")}")
            ) {
                Icon(
                    imageVector = Icons.Default.PlayCircleFilled,
                    contentDescription = null,
                    tint = NeonCyanPrimary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Test \"${command.testQuery}\"",
                    color = NeonCyanPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
