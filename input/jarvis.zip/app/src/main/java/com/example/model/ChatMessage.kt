package com.example.model

enum class SenderType {
    USER,
    JARVIS
}

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val sender: SenderType,
    val timestamp: Long = System.currentTimeMillis(),
    val actionExecuted: String? = null,
    val isAppLaunch: Boolean = false,
    val isError: Boolean = false,
    val playStorePackage: String? = null,
    val intentAction: String? = null
)
