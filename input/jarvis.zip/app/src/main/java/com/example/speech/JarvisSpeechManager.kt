package com.example.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale

class JarvisSpeechManager(
    private val context: Context,
    private val onVoiceRmsChanged: (Float) -> Unit,
    private val onSpeechResult: (String) -> Unit,
    private val onSpeechError: (String) -> Unit,
    private val onTtsStart: () -> Unit,
    private val onTtsDone: () -> Unit
) {
    private val tag = "JarvisSpeech"
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsInitialized = false
    private var isHindiAvailable = false

    init {
        initTts()
    }

    private fun initTts() {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val hindiLocale = Locale("hi", "IN")
                val result = textToSpeech?.setLanguage(hindiLocale)
                if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                    val genericHindi = Locale("hi")
                    val fallbackResult = textToSpeech?.setLanguage(genericHindi)
                    isHindiAvailable = !(fallbackResult == TextToSpeech.LANG_MISSING_DATA || fallbackResult == TextToSpeech.LANG_NOT_SUPPORTED)
                    if (!isHindiAvailable) {
                        textToSpeech?.language = Locale.ENGLISH
                        Log.w(tag, "Hindi TTS not supported on device; defaulting to English")
                    } else {
                        Log.i(tag, "Hindi generic TTS initialized")
                    }
                } else {
                    isHindiAvailable = true
                    Log.i(tag, "Hindi (India) TTS initialized successfully")
                }
                textToSpeech?.setPitch(1.05f)
                textToSpeech?.setSpeechRate(0.98f)

                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        onTtsStart()
                    }

                    override fun onDone(utteranceId: String?) {
                        onTtsDone()
                    }

                    override fun onError(utteranceId: String?) {
                        onTtsDone()
                    }
                })
                isTtsInitialized = true
            } else {
                Log.e(tag, "TTS Initialization failed with code $status")
            }
        }
    }

    fun speak(text: String, isMuted: Boolean = false) {
        if (isMuted || !isTtsInitialized || textToSpeech == null) {
            onTtsDone()
            return
        }

        stopSpeaking()

        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "jarvis_${System.currentTimeMillis()}")
        }
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "jarvis_msg")
    }

    fun stopSpeaking() {
        try {
            if (textToSpeech?.isSpeaking == true) {
                textToSpeech?.stop()
            }
        } catch (e: Exception) {
            Log.e(tag, "Error stopping TTS", e)
        }
        onTtsDone()
    }

    fun isRecognitionAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    fun startListening(languageCode: String = "hi-IN") {
        stopSpeaking()

        if (!isRecognitionAvailable()) {
            onSpeechError("स्पीच रिकग्निशन सर्विस उपलब्ध नहीं है। (Speech recognition unavailable)")
            return
        }

        try {
            stopListening()

            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        onVoiceRmsChanged(1f)
                    }

                    override fun onBeginningOfSpeech() {
                        onVoiceRmsChanged(3f)
                    }

                    override fun onRmsChanged(rmsdB: Float) {
                        onVoiceRmsChanged(rmsdB.coerceAtLeast(0f))
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        onVoiceRmsChanged(0f)
                    }

                    override fun onError(error: Int) {
                        val errorMessage = when (error) {
                            SpeechRecognizer.ERROR_AUDIO -> "ऑडियो रिकॉर्डिंग में त्रुटि (Audio recording error)"
                            SpeechRecognizer.ERROR_CLIENT -> "क्लाइंट त्रुटि (Client error)"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "माइक की अनुमति नहीं मिली (Microphone permission required)"
                            SpeechRecognizer.ERROR_NETWORK -> "नेटवर्क त्रुटि (Network error)"
                            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "नेटवर्क टाइमआउट (Network timeout)"
                            SpeechRecognizer.ERROR_NO_MATCH -> "कुछ सुनाई नहीं दिया, कृपया फिर से बोलें (No speech heard, please try again)"
                            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "जार्विस व्यस्त है, कृपया पुनः प्रयास करें (Speech recognizer busy)"
                            SpeechRecognizer.ERROR_SERVER -> "सर्वर त्रुटि (Server error)"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "आवाज नहीं पहचानी गई (No speech recognized in time)"
                            else -> "पहचान में समस्या आई (Voice recognition error)"
                        }
                        onVoiceRmsChanged(0f)
                        onSpeechError(errorMessage)
                    }

                    override fun onResults(results: Bundle?) {
                        onVoiceRmsChanged(0f)
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            onSpeechResult(matches[0])
                        } else {
                            onSpeechError("कोई कमांड नहीं मिली (No command detected)")
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            // Can show live partials if desired
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageCode)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageCode)
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS is listening...")
            }

            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            Log.e(tag, "Failed to start speech recognizer", e)
            onSpeechError("माइक शुरू करने में समस्या आई: ${e.localizedMessage}")
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        } catch (e: Exception) {
            Log.e(tag, "Error stopping recognizer", e)
        } finally {
            speechRecognizer = null
            onVoiceRmsChanged(0f)
        }
    }

    fun getFallbackSpeechIntent(languageCode: String = "hi-IN"): Intent {
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageCode)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS: Speak in Hindi or English")
        }
    }

    fun destroy() {
        stopListening()
        stopSpeaking()
        try {
            textToSpeech?.shutdown()
        } catch (e: Exception) {
            Log.e(tag, "Error shutting down TTS", e)
        }
        textToSpeech = null
    }
}
