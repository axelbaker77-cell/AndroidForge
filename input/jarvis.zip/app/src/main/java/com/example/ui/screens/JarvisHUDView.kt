package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.VoiceState
import com.example.ui.components.JarvisArcReactor
import com.example.ui.components.JarvisMicButton
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberRed
import com.example.ui.theme.DarkContainer
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DeepSpaceBackground
import com.example.ui.theme.NeonCyanPrimary
import com.example.ui.theme.NeonSkySecondary
import com.example.ui.theme.TextCyanSecondary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhitePrimary

@Composable
fun JarvisHUDView(
    voiceState: VoiceState,
    lastTranscript: String,
    onMicTapped: () -> Unit,
    onPermissionDenied: () -> Unit,
    onSelectCommand: (String) -> Unit,
    onNavigateToChat: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DeepSpaceBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // 1. Arc Reactor Hologram Section
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 8.dp)
        ) {
            JarvisArcReactor(
                voiceState = voiceState,
                size = 210.dp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // State Banner
            val (statusText, statusColor) = when (voiceState) {
                is VoiceState.Listening -> "LISTENING TO VOICE..." to CyberGreen
                is VoiceState.Speaking -> "JARVIS SPEAKING IN HINDI..." to NeonCyanPrimary
                is VoiceState.Processing -> "PROCESSING COMMAND..." to CyberPurple
                is VoiceState.Error -> "SYSTEM ALERT" to CyberRed
                VoiceState.Idle -> "CORE SYSTEM READY" to NeonSkySecondary
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(DarkContainer)
                    .border(1.dp, statusColor.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    text = statusText,
                    color = statusColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 2. Transcript & Assistant Feedback Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderCyanGlow.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant.copy(alpha = 0.7f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "VOICE TRANSCRIPT & FEEDBACK",
                    color = TextCyanSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (lastTranscript.isNotBlank()) lastTranscript else "Tap the microphone below and speak a command like \"YouTube kholo\" or \"WhatsApp kholo\"...",
                    color = if (lastTranscript.isNotBlank()) TextWhitePrimary else TextMuted,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )

                if (voiceState is VoiceState.Speaking) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "🔊 Speaking response aloud in Hindi",
                        color = NeonCyanPrimary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 3. Quick Action Voice Command Chips
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "QUICK VOICE COMMANDS",
                    color = TextCyanSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Text(
                    text = "Switch to Chat",
                    color = NeonCyanPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable { onNavigateToChat() }
                        .padding(4.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Horizontal scrolling quick command chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickCommandChip(
                    label = "YouTube kholo",
                    hindi = "यूट्यूब खोलो",
                    icon = Icons.Default.PlayArrow,
                    onClick = { onSelectCommand("YouTube kholo") }
                )
                QuickCommandChip(
                    label = "WhatsApp kholo",
                    hindi = "व्हाट्सएप खोलो",
                    icon = Icons.Default.Chat,
                    onClick = { onSelectCommand("WhatsApp kholo") }
                )
                QuickCommandChip(
                    label = "Camera kholo",
                    hindi = "कैमरा खोलो",
                    icon = Icons.Default.CameraAlt,
                    onClick = { onSelectCommand("Camera kholo") }
                )
                QuickCommandChip(
                    label = "Maps kholo",
                    hindi = "मैप्स खोलो",
                    icon = Icons.Default.Map,
                    onClick = { onSelectCommand("Maps kholo") }
                )
                QuickCommandChip(
                    label = "Chrome kholo",
                    hindi = "क्रोम खोलो",
                    icon = Icons.Default.Language,
                    onClick = { onSelectCommand("Chrome kholo") }
                )
                QuickCommandChip(
                    label = "Time kya hai?",
                    hindi = "समय क्या है?",
                    icon = Icons.Default.Schedule,
                    onClick = { onSelectCommand("Time kya hua hai") }
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 4. Glowing Centerpiece Microphone Button
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            JarvisMicButton(
                voiceState = voiceState,
                onMicTapped = onMicTapped,
                onPermissionDenied = onPermissionDenied
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = if (voiceState is VoiceState.Listening) {
                    "Listening... Tap to stop"
                } else {
                    "Tap to speak (Hindi or English)"
                },
                color = if (voiceState is VoiceState.Listening) CyberGreen else TextCyanSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )

            Text(
                text = "Privacy Protected: Zero background listening",
                color = TextMuted,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

@Composable
fun QuickCommandChip(
    label: String,
    hindi: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(DarkContainer)
            .border(1.dp, BorderCyanGlow.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = NeonCyanPrimary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Text(
                    text = label,
                    color = TextWhitePrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = hindi,
                    color = TextCyanSecondary,
                    fontSize = 10.sp
                )
            }
        }
    }
}
