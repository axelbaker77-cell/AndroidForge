package com.example.model

sealed interface VoiceState {
    data object Idle : VoiceState
    data class Listening(val rmsDb: Float = 0f) : VoiceState
    data class Processing(val recognizedText: String) : VoiceState
    data class Speaking(val text: String) : VoiceState
    data class Error(val errorMessage: String) : VoiceState
}

enum class AssistantTab {
    CORE_HUD,
    CHAT,
    COMMANDS,
    SYSTEM_STATUS
}

enum class VoiceLanguage(val code: String, val label: String, val nativeName: String) {
    HINDI_ENGLISH("hi-IN", "Auto (HI/EN)", "हिन्दी / English"),
    HINDI("hi-IN", "Hindi", "हिन्दी"),
    ENGLISH("en-IN", "English", "English")
}
