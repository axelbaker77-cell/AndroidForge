package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.CrisisAlert
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AssistantTab
import com.example.ui.theme.BorderCyanGlow
import com.example.ui.theme.DarkContainer
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.NeonCyanPrimary
import com.example.ui.theme.NeonSkySecondary
import com.example.ui.theme.TextCyanSecondary
import com.example.ui.theme.TextMuted

@Composable
fun JarvisBottomNav(
    currentTab: AssistantTab,
    onTabSelected: (AssistantTab) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = BorderCyanGlow.copy(alpha = 0.3f))
            .navigationBarsPadding(),
        containerColor = DarkContainer,
        tonalElevation = 8.dp
    ) {
        // Tab 1: HUD Core
        NavigationBarItem(
            selected = currentTab == AssistantTab.CORE_HUD,
            onClick = { onTabSelected(AssistantTab.CORE_HUD) },
            icon = {
                Icon(
                    imageVector = if (currentTab == AssistantTab.CORE_HUD) Icons.Filled.CrisisAlert else Icons.Outlined.CrisisAlert,
                    contentDescription = "Core HUD"
                )
            },
            label = {
                Text(
                    text = "HUD CORE",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (currentTab == AssistantTab.CORE_HUD) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = navigationBarColors(),
            modifier = Modifier.testTag("nav_tab_core")
        )

        // Tab 2: Chat Terminal
        NavigationBarItem(
            selected = currentTab == AssistantTab.CHAT,
            onClick = { onTabSelected(AssistantTab.CHAT) },
            icon = {
                Icon(
                    imageVector = if (currentTab == AssistantTab.CHAT) Icons.Filled.Chat else Icons.Outlined.Chat,
                    contentDescription = "Chat Terminal"
                )
            },
            label = {
                Text(
                    text = "TERMINAL",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (currentTab == AssistantTab.CHAT) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = navigationBarColors(),
            modifier = Modifier.testTag("nav_tab_chat")
        )

        // Tab 3: Command Matrix
        NavigationBarItem(
            selected = currentTab == AssistantTab.COMMANDS,
            onClick = { onTabSelected(AssistantTab.COMMANDS) },
            icon = {
                Icon(
                    imageVector = if (currentTab == AssistantTab.COMMANDS) Icons.Filled.GridView else Icons.Outlined.GridView,
                    contentDescription = "Command Matrix"
                )
            },
            label = {
                Text(
                    text = "MATRIX",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (currentTab == AssistantTab.COMMANDS) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = navigationBarColors(),
            modifier = Modifier.testTag("nav_tab_matrix")
        )

        // Tab 4: Diagnostics & Status
        NavigationBarItem(
            selected = currentTab == AssistantTab.SYSTEM_STATUS,
            onClick = { onTabSelected(AssistantTab.SYSTEM_STATUS) },
            icon = {
                Icon(
                    imageVector = if (currentTab == AssistantTab.SYSTEM_STATUS) Icons.Filled.CheckCircle else Icons.Outlined.CheckCircle,
                    contentDescription = "App Diagnostics"
                )
            },
            label = {
                Text(
                    text = "STATUS",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (currentTab == AssistantTab.SYSTEM_STATUS) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = navigationBarColors(),
            modifier = Modifier.testTag("nav_tab_status")
        )
    }
}

@Composable
private fun navigationBarColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = Color.Black,
    selectedTextColor = NeonCyanPrimary,
    indicatorColor = NeonCyanPrimary,
    unselectedIconColor = TextCyanSecondary,
    unselectedTextColor = TextMuted
)
