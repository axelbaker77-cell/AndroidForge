package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.engine.JarvisCommandEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("JARVIS", appName)
    }

    @Test
    fun `test youtube command parsing`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val engine = JarvisCommandEngine(context)
        val result = engine.executeQuery("YouTube kholo")

        // Should match YouTube either as launch or not installed on test runner
        assertNotNull(result)
        assertTrue(result.actionExecuted?.contains("YouTube") == true)
        assertTrue(result.spokenResponseHindi.contains("यूट्यूब"))
    }

    @Test
    fun `test time command in hindi`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val engine = JarvisCommandEngine(context)
        val result = engine.executeQuery("time kya hua hai")

        assertNotNull(result)
        assertEquals("Queried Time", result.actionExecuted)
        assertTrue(result.spokenResponseHindi.contains("बजकर"))
    }

    @Test
    fun `test math calculation in hindi`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val engine = JarvisCommandEngine(context)
        val result = engine.executeQuery("50 + 25 kitna hoga")

        assertNotNull(result)
        assertTrue(result.spokenResponseHindi.contains("75"))
    }
}
